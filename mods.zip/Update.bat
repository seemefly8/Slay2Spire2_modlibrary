@echo off
chcp 65001 >nul
title 杀戮尖塔2 Mod 自动同步工具 - GitHub 清空重下版
color 0A

:: ====================== 重要配置 ======================
:: 换成你自己的 GitHub mods.zip 直链
set "MOD_ZIP_URL=https://github.com/469554f5-e70c-4678-bfc0-4c3c538b59dd" 
:: ======================================================

:: 关键：使用脚本当前目录（相对路径）
set "GAME_MOD_DIR=%~dp0"
set "TEMP_ZIP=%temp%\Slay2_Mod_Latest.zip"
set "POWERSHELL=powershell -Command"

echo.
echo ==============================================
echo          杀戮尖塔2 Mod 同步工具
echo           模式：清空本地 + 重新下载
echo ==============================================
echo 当前Mod目录：%GAME_MOD_DIR%
echo.

echo ==============================================
echo [1/3] 正在删除所有本地旧Mod文件...
echo ==============================================
:: 删除当前目录下所有文件/文件夹，静默强制删除
del /f /s /q "%GAME_MOD_DIR%\*" 2>nul
:: 删除子文件夹（保留当前目录）
for /d %%i in ("%GAME_MOD_DIR%\*") do rd /s /q "%%i"
echo 旧Mod已全部清空！

echo.
echo ==============================================
echo [2/3] 正在从 GitHub 下载最新Mod...
echo ==============================================
%POWERSHELL% "(New-Object Net.WebClient).DownloadFile('%MOD_ZIP_URL%', '%TEMP_ZIP%')"

if not exist "%TEMP_ZIP%" (
    echo.
    echo [错误] 下载失败！检查网络或链接是否正确
    pause
    exit /b 1
)
echo 下载完成！

echo.
echo ==============================================
echo [3/3] 正在解压并覆盖安装...
echo ==============================================
%POWERSHELL% "Expand-Archive -Path '%TEMP_ZIP%' -DestinationPath '%GAME_MOD_DIR%' -Force"

:: 清理临时文件
del "%TEMP_ZIP%" 2>nul

echo.
echo ==============================================
echo              ✅ 同步完成！
echo ==============================================
echo 已删除所有旧Mod
echo 已安装 GitHub 最新完整版
echo 重启游戏即可生效！
echo.
pause
exit /b 0